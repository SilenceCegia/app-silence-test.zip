<div style="text-align:center; padding-bottom: 16px; color: #FFF; font-size: 1.1rem; ">
    <a class="mr-3" href="/politiques-confidentialites" target="_blank"
        style="text-decoration: underline;">
        Politiques de confidentialité
    </a> - <a class="ms-3" href="/mentions-legales" target="_blank" style="text-decoration: underline;">
        Mentions légales
    </a>
</div>

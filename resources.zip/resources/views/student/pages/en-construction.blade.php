@extends('student.layouts.page', array('contentBackground' => '#33395e') )

@section('content')

    <div class="container-fluid">
        <h1 style="color: #FFF; margin-top: 25px;">Page en construction</h1>
    </div>

@endsection


<nav id="teacher-sidebar">

    <a href="/student/plateau" class="icon-wrapper">
        <i class="fas fa-home"></i> Mon plateau
    </a>

    <a href="/student/plateau" class="icon-wrapper">
        <i class="fas fa-chart-simple"></i> Les productions
    </a>

    <a href="/student/ateliers" class="icon-wrapper">
        <i class="fas fa-book"></i> Les ateliers
    </a>

    <a href="/student/action" class="icon-wrapper">
        <i class="far fa-comment-dots"></i> ACTION!
    </a>

    <a href="/student/plateau" class="icon-wrapper">
        <i class="fas fa-"></i> Ressources
    </a>

    <a href="/student/plateau" class="icon-wrapper">
        <i class="fas fa-helps"></i> Help Center
    </a>
  

    {{--
    <a href="/teacher/dashboard" class="icon-wrapper">
        <i class="fas fa-cog"></i> Paramètres
    </a> --}}

    {{-- <a href="#" class="icon-wrapper" style="position: absolute; bottom: 16px;" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
        <i class="fas fa-user-circle icon" style="font-size: 4.5rem;"></i>
    </a> --}}

    <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
        @csrf
    </form>

</nav>

